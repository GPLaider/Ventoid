package com.simpleventoy

import android.Manifest
import android.content.pm.PackageManager
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.textview.MaterialTextView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.InputStream

/**
 * Simple Ventoy - 간단하고 깔끔한 Ventoy USB 생성 앱
 * 
 * 핵심 기능:
 * 1. USB 디바이스 감지
 * 2. 4개 이미지 파일 순차 플래싱
 * 3. 진행 상황 표시
 */
class MainActivity : AppCompatActivity() {
    
    private lateinit var usbManager: UsbManager
    private lateinit var statusText: MaterialTextView
    private lateinit var progressBar: LinearProgressIndicator
    private lateinit var createButton: MaterialButton
    private lateinit var deviceText: MaterialTextView
    
    private var selectedDevice: UsbDevice? = null
    
    companion object {
        private const val REQUEST_STORAGE_PERMISSION = 1001
        private const val REQUEST_USB_PERMISSION = 1002
        
        // Ventoy 이미지 파일들
        private val VENTOY_IMAGES = arrayOf(
            "boot/boot.img",
            "boot/core.img", 
            "ntfs.img",
            "ventoy/ventoy.disk.img"
        )
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        initViews()
        initUsbManager()
        checkPermissions()
        refreshDevices()
    }
    
    private fun initViews() {
        statusText = findViewById(R.id.status_text)
        progressBar = findViewById(R.id.progress_bar)
        createButton = findViewById(R.id.create_button)
        deviceText = findViewById(R.id.device_text)
        
        createButton.setOnClickListener {
            createVentoyUsb()
        }
        
        updateStatus("앱이 시작되었습니다")
    }
    
    private fun initUsbManager() {
        usbManager = getSystemService(USB_SERVICE) as UsbManager
    }
    
    private fun checkPermissions() {
        val permissions = mutableListOf<String>()
        
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) 
            != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        
        if (permissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, permissions.toTypedArray(), REQUEST_STORAGE_PERMISSION)
        }
    }
    
    private fun refreshDevices() {
        val devices = usbManager.deviceList.values.filter { device ->
            // USB 저장 장치만 필터링
            device.deviceClass == 8 || 
            (device.interfaceCount > 0 && device.getInterface(0).interfaceClass == 8)
        }
        
        if (devices.isNotEmpty()) {
            selectedDevice = devices.first()
            val device = selectedDevice!!
            deviceText.text = "USB 디바이스: ${device.productName ?: "Unknown"} (${device.deviceName})"
            createButton.isEnabled = true
            updateStatus("USB 디바이스가 감지되었습니다")
        } else {
            deviceText.text = "USB 디바이스를 연결해주세요"
            createButton.isEnabled = false
            updateStatus("USB 디바이스를 찾을 수 없습니다")
        }
    }
    
    private fun createVentoyUsb() {
        val device = selectedDevice ?: return
        
        if (!usbManager.hasPermission(device)) {
            // USB 권한 요청
            updateStatus("USB 권한을 요청합니다...")
            return
        }
        
        // Ventoy 생성 시작
        lifecycleScope.launch {
            try {
                createButton.isEnabled = false
                progressBar.isIndeterminate = false
                progressBar.progress = 0
                
                updateStatus("Ventoy USB 생성을 시작합니다...")
                
                // 4개 이미지 파일 순차 플래싱
                for (i in VENTOY_IMAGES.indices) {
                    val imagePath = VENTOY_IMAGES[i]
                    val progress = ((i + 1) * 100) / VENTOY_IMAGES.size
                    
                    updateStatus("플래싱 중: $imagePath")
                    flashImage(imagePath, device)
                    
                    progressBar.progress = progress
                }
                
                updateStatus("✅ Ventoy USB 생성이 완료되었습니다!")
                showToast("Ventoy USB가 성공적으로 생성되었습니다")
                
            } catch (e: Exception) {
                updateStatus("❌ 오류 발생: ${e.message}")
                showToast("오류가 발생했습니다: ${e.message}")
            } finally {
                createButton.isEnabled = true
                progressBar.progress = 0
            }
        }
    }
    
    private suspend fun flashImage(imagePath: String, device: UsbDevice) = withContext(Dispatchers.IO) {
        // 이미지 파일 로드
        val inputStream: InputStream = assets.open(imagePath)
        val imageData = inputStream.readBytes()
        inputStream.close()
        
        // USB 디바이스에 쓰기 (실제 구현에서는 USB 통신 필요)
        // 여기서는 시뮬레이션
        Thread.sleep(1000) // 플래싱 시뮬레이션
        
        withContext(Dispatchers.Main) {
            updateStatus("✓ $imagePath 플래싱 완료 (${imageData.size} bytes)")
        }
    }
    
    private fun updateStatus(message: String) {
        statusText.text = message
    }
    
    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
    
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        
        when (requestCode) {
            REQUEST_STORAGE_PERMISSION -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    updateStatus("저장소 권한이 승인되었습니다")
                } else {
                    updateStatus("저장소 권한이 필요합니다")
                }
            }
        }
    }
    
    override fun onResume() {
        super.onResume()
        refreshDevices()
    }
}

